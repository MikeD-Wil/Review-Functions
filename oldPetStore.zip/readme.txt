Pet Store Project Part A - Wireframe
•
Oct 22
Due Oct 22, 5:00 PM
Today we will be starting our pet store project which we will be working with over the next few weeks.
Watch this video on wireframing before starting
https://www.youtube.com/watch?v=PmmQjLqJQlY

1.You will be starting by creating a wireframe of your website that you will submit to the instructor before you begin any coding.
2. All of your pages should have the same navigation bar
3. All of your pages should have the same footer
4. Your pet store should have a contact page
5. The pet store needs a landing page/home page
6. The Pet store needs an about me page.